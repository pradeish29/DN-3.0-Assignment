package com.library.aspect;

public class LoggingAspect {
    public void logg() {
        System.out.print("this is a AOP logging");
    }
}
